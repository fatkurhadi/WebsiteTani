<?php
header('location:media.php?dashboard');
?>